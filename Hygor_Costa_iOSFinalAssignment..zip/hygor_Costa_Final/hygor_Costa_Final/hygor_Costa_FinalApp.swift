//
//  hygor_Costa_FinalApp.swift
//  hygor_Costa_Final
//
//  Created by Hygor Costa on 2022-11-30.
//

import SwiftUI

@main
struct hygor_Costa_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
